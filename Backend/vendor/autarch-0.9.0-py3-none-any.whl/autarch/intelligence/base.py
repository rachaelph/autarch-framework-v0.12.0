"""The model provider interface — the single seam between Autarch and any AI.

A future fine-tuned 'OurModel' drops in here without touching the kernel.
"""
from __future__ import annotations

from abc import ABC, abstractmethod
from typing import Optional


class ModelProvider(ABC):
    """A voice in the council. The only thing Autarch asks of intelligence."""

    name: str = "provider"

    @abstractmethod
    def complete(self, prompt: str, system: Optional[str] = None) -> str:
        """Return a text completion for `prompt`."""
        raise NotImplementedError
