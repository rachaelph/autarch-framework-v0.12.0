"""Small shared utilities."""
from __future__ import annotations

import json
import re
import sqlite3
from typing import Optional

_FENCE_RE = re.compile(r"```(?:json)?\s*(.*?)```", re.S | re.I)


def configure_sqlite(conn: sqlite3.Connection) -> None:
    """Tune a SQLite connection for safe concurrent local-first use.

    All settings are stdlib-only (no external services): WAL lets readers and a
    writer proceed concurrently, a busy timeout makes contending connections wait
    briefly instead of erroring, and NORMAL synchronous is the safe, fast pairing
    with WAL. In-memory databases ignore WAL harmlessly.
    """
    try:
        conn.execute("PRAGMA journal_mode=WAL")
        conn.execute("PRAGMA synchronous=NORMAL")
        conn.execute("PRAGMA busy_timeout=5000")
    except sqlite3.Error:
        # Never let a pragma tweak break opening the database.
        pass


def _load_object(text: str) -> Optional[dict]:
    """Parse `text` as JSON, returning it only if it is an object."""
    try:
        obj = json.loads(text)
    except Exception:
        return None
    return obj if isinstance(obj, dict) else None


def _first_balanced_object(text: str) -> Optional[str]:
    """Return the first complete, balanced ``{...}`` block in `text`.

    Brace-counts while respecting string literals and escapes, so it survives
    trailing prose, multiple objects, or braces inside string values.
    """
    start = text.find("{")
    if start == -1:
        return None
    depth = 0
    in_string = False
    escaped = False
    for i in range(start, len(text)):
        ch = text[i]
        if in_string:
            if escaped:
                escaped = False
            elif ch == "\\":
                escaped = True
            elif ch == '"':
                in_string = False
            continue
        if ch == '"':
            in_string = True
        elif ch == "{":
            depth += 1
        elif ch == "}":
            depth -= 1
            if depth == 0:
                return text[start : i + 1]
    return None


def extract_json(text: str) -> Optional[dict]:
    """Best-effort extraction of a JSON object from model output.

    Real models wrap JSON in prose, markdown fences, or trailing commentary. This
    pulls out the first valid object regardless. Returns None if nothing
    parseable is found.
    """
    if not text:
        return None

    candidate = text.strip()

    # If the model fenced its answer (```json ... ```), prefer the fenced block.
    fenced = _FENCE_RE.search(candidate)
    if fenced:
        candidate = fenced.group(1).strip()

    # Try the whole thing first (the happy path for JSON-mode models).
    obj = _load_object(candidate)
    if obj is not None:
        return obj

    # Otherwise scan for the first complete, balanced object.
    block = _first_balanced_object(candidate)
    if block is not None:
        return _load_object(block)
    return None
